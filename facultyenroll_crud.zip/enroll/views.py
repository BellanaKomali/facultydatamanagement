from django.shortcuts import render,HttpResponseRedirect
from .forms import facultyRegistration
from .models import user
#function to display data
def add_show(request): 
    if request.method == 'POST':
        fm=facultyRegistration(request.POST)
        if fm.is_valid():
            nm=fm.cleaned_data['name']
            em=fm.cleaned_data['email']
            pw=fm.cleaned_data['password']
            reg=user(name=nm,email=em,password=pw)
            reg.save()
            fm=facultyRegistration()
    else:
        fm=facultyRegistration()
    faculty=user.objects.all()

    return render(request,'enroll/addandshow.html',{'form':fm,'fac':faculty})
#Function to delete data
def delete_record(request,id):
    if request.method=="POST":
        pi=user.objects.get(pk=id)
        pi.delete()
        return HttpResponseRedirect('/') 
#function for updating records
def update_record(request,id):
    if request.method=='POST':
        pi=user.objects.get(pk=id)
        fm=facultyRegistration(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
    else:
        pi=user.objects.get(pk=id)
        fm=facultyRegistration(instance=pi)
    return render(request,'enroll/updatefaculty.html',{'form':fm})

